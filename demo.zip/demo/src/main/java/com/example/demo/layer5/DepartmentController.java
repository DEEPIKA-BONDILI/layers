package com.example.demo.layer5;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Department5;
import com.example.demo.layer4.DepartmentService;

/*@RestController  //REpresentational State Transfer html xml json
public class DepartmentController {

	@Autowired
	DepartmentService deptServ;
	
	@GetMapping(path="/getDept")
	@ResponseBody
	public Department5 getDepartment() {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		Department5 dept = deptServ.findDepartmentService(21);
		return dept;
		
	}
	
	
	@GetMapping(path="/getDepts")
	@ResponseBody
	public List<Department5> getAllDepartments() {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		List<Department5> deptList = deptServ.findDepartmentsService();
		return deptList;
		
	}
}
*/
@RestController 
public class DepartmentController {
    @Autowired
    DepartmentService deptServ;
    
    @GetMapping(path="/getDept/{mydno}") //Get Request in Postman http://localhost:8080/getDept/1
    @ResponseBody
    public Department5 getDepartment(@PathVariable("mydno") Integer dno) {
        System.out.println("Department Controller....Understanding client and talking to service layer...");
        Department5 dept = deptServ.findDepartmentService(dno);
        return dept;        
    }
    
    
    @GetMapping(path="/getDepts")
    @ResponseBody
    public List<Department5> getAllDepartments() {
        System.out.println("Department Controller....Understanding client and talking to service layer...");
        List<Department5> deptList = deptServ.findDepartmentsService();
        return deptList;
        
    }
    
    @PostMapping(path="/addDept")
    public String addDepartment(@RequestBody Department5 dept) {
        deptServ.addDepartmentService(dept);
        return "department added successfully";
    }
    
}
